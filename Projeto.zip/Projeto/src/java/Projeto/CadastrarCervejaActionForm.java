/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Projeto;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/**
 *
 * @author Guilherme
 */
public class CadastrarCervejaActionForm extends org.apache.struts.action.ActionForm {
    private List<Cerveja> cervejas = new ArrayList<>();
    private List<Fabricante> fabricantes = new ArrayList<>();
    private int fabricante;
    private String nome;
    private String coloracao;
    private String alcool;

    @Override
    public void reset(ActionMapping mapping, HttpServletRequest request) {
        fabricante = 0;
        nome = "";
        coloracao="";
        alcool="";
    }

    /**
     * This is the action called from the Struts framework.
     *
     * @param mapping The ActionMapping used to select this instance.
     * @param request The HTTP Request we are processing.
     * @return
     */
    public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        if (getNome() == null || getNome().equals("")) {
            errors.add("nome", new ActionMessage("error.nome.required"));
        }
        if (getColoracao()== null || getColoracao().equals("")) {
            errors.add("coloracao", new ActionMessage("error.coloracao.required"));
        }
        if (getNome() == null || getNome().equals("")) {
            errors.add("alcool", new ActionMessage("error.alocool.required"));
        }
        if (getFabricante() < 1) {
            errors.add("fabricante", new ActionMessage("error.fabricante.required"));
         }
        return errors;
    }

    public List<Cerveja> getCervejas() {
        return cervejas;
    }

    public void setCervejas(List<Cerveja> cervejas) {
        this.cervejas = cervejas;
    }

    public List<Fabricante> getFabricantes() {
        return fabricantes;
    }

    public void setFabricantes(List<Fabricante> fabricantes) {
        this.fabricantes = fabricantes;
    }

    public int getFabricante() {
        return fabricante;
    }

    public void setFabricante(int fabricante) {
        this.fabricante = fabricante;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getColoracao() {
        return coloracao;
    }

    public void setColoracao(String coloracao) {
        this.coloracao = coloracao;
    }

    public String getAlcool() {
        return alcool;
    }

    public void setAlcool(String alcool) {
        this.alcool = alcool;
    }
}
