/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Projeto;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/**
 *
 * @author Guilherme
 */
public class CadastrarFabricanteActionForm extends org.apache.struts.action.ActionForm {
    
    private List<Fabricante> fabricantes = new ArrayList<>();
    private String nome;
    private String local;
    private String descricao;

    @Override
    public void reset(ActionMapping mapping, HttpServletRequest request) {
        nome = "";
        local = "";
        descricao = "";
    }
    
    public CadastrarFabricanteActionForm() {
        super();
    }
    

    /**
     * This is the action called from the Struts framework.
     *
     * @param mapping The ActionMapping used to select this instance.
     * @param request The HTTP Request we are processing.
     * @return
     */
    public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        if (getNome() == null || getNome().equals("")) {
            errors.add("nome", new ActionMessage("error.nome.required"));
        }
        if (getLocal()== null || getLocal().equals("")) {
            errors.add("local", new ActionMessage("error.local.required"));
        }
        if (getDescricao()== null || getDescricao().equals("")) {
            errors.add("descricao", new ActionMessage("error.descricao.required"));
        }
        return errors;
    }

    public List<Fabricante> getFabricantes() {
        return fabricantes;
    }

    public void setFabricantes(List<Fabricante> fabricantes) {
        this.fabricantes = fabricantes;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
